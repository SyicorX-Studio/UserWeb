import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';

const GlassBottleViewer = () => {

  return (
    <div
      style={{ width: '100%', height: '100%', position: 'relative' }}
    />
  );
};

export default GlassBottleViewer;
